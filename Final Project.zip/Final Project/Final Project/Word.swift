//
//  Word.swift
//  Final Project
//
//  Created by 张泽华 on 2020/4/21.
//  Copyright © 2020 张泽华. All rights reserved.
//

//import Foundation
//
//struct lexicalEntries {
//    var entries: [entries]
//}
//struct entries {
//    var senses: [senses]
//}
//struct senses {
//    var definitions: [definitions]
//}
//
//struct definitions {
//    var definitions: [String]
//}
