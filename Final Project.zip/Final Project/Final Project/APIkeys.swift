//
//  APIkeys.swift
//  WeatherGift
//
//  Created by 张泽华 on 2020/3/18.
//  Copyright © 2020 张泽华. All rights reserved.
//

import Foundation
struct APIkeys{
    static let googlePlacesKey = "AIzaSyBLsyRilbuh8AOK2CG8TtJ9SlRP6RHP6hU"
    static let dictionaryKey = "68e38766d0409e0ca71fa2bbb96d466b"
    static let darkSkyKey = "caa02557a4ba9e6aa1221d724a0b7246"
    static let dictionaryID = "d068abad"
}

struct APIurls{
    static let darkSkyURL = "https://api.darksky.net/forecast/"
    static let dictionaryURL = "https://od-api.oxforddictionaries.com/api/v2"
}




